document.addEventListener('DOMContentLoaded', () => {
    const board = document.querySelector('.board');
    const cells = document.querySelectorAll('.cell');
    const message = document.querySelector('.message');
    const resetButton = document.querySelector('#reset-btn');
    const onePlayerButton = document.querySelector('#one-player-btn');
    const twoPlayerButton = document.querySelector('#two-player-btn');

    let currentPlayer = 'X';
    let gameBoard = ['', '', '', '', '', '', '', '', ''];
    let gameActive = false;
    let gameMode = null;

    const winningCombinations = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
    ];

    function checkWinner() {
        for (const combination of winningCombinations) {
            const [a, b, c] = combination;
            if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
                return gameBoard[a];
            }
        }

        if (!gameBoard.includes('')) {
            return 'draw';
        }

        return null;
    }

    function updateMessage(text) {
        message.textContent = text;
    }

    function handleCellClick(index) {
        if (!gameActive || gameBoard[index] !== '') return;

        gameBoard[index] = currentPlayer;
        cells[index].textContent = currentPlayer;
        cells[index].classList.add(currentPlayer);

        const winner = checkWinner();

        if (winner) {
            gameActive = false;
            if (winner === 'draw') {
                updateMessage('Ничья!');
            } else {
                updateMessage(`Победил ${winner}!`);
            }
            return;
        }

        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
        updateMessage(`Ходит ${currentPlayer}`);

        if (gameMode === 'onePlayer' && currentPlayer === 'O') {
            setTimeout(makeBotMove, 500);
        }
    }


    function makeBotMove() {
        let availableMoves = [];
        for (let i = 0; i < gameBoard.length; i++) {
            if (gameBoard[i] === '') {
                availableMoves.push(i);
            }
        }

        if (availableMoves.length > 0) {
            const randomIndex = Math.floor(Math.random() * availableMoves.length);
            const move = availableMoves[randomIndex];
            handleCellClick(move);
        }
    }

    function resetGame() {
        gameBoard = ['', '', '', '', '', '', '', '', ''];
        gameActive = false;
        currentPlayer = 'X';
        updateMessage('');

        cells.forEach(cell => {
            cell.textContent = '';
            cell.classList.remove('X', 'O');
        });
    }

    function startGame(mode) {
        resetGame();
        gameMode = mode;
        gameActive = true;
        updateMessage(`Ходит ${currentPlayer}`);

        if (mode === 'onePlayer' && currentPlayer === 'O') {
            setTimeout(makeBotMove, 500);
        }
    }

    cells.forEach((cell, index) => {
        cell.addEventListener('click', () => handleCellClick(index));
    });

    resetButton.addEventListener('click', resetGame);

    onePlayerButton.addEventListener('click', () => startGame('onePlayer'));
    twoPlayerButton.addEventListener('click', () => startGame('twoPlayer'));
});